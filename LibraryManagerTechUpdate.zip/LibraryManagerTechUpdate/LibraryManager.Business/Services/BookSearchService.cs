using FuzzySharp;
using LibraryManager.Data.Models;

namespace LibraryManager.Service.Services
{
    public class BookSearchService
    {
        private readonly BookService _bookService;

        public BookSearchService(BookService bookService)
        {
            _bookService = bookService;
        }

        public IEnumerable<Book> Search(string searchTerm)
        {
            // If the search term is empty, return all books
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return _bookService.GetAll();
            }

            // Get all books and apply fuzzy matching
            return _bookService.GetAll()
                .Select(book => new
                {
                    Book = book,
                    Score = Fuzz.Ratio(book.Title.ToLower(), searchTerm.ToLower())
                })
                .Where(result => result.Score > 50) 
                .OrderByDescending(result => result.Score)
                .Select(result => result.Book)
                .ToList();
        }
    }
}