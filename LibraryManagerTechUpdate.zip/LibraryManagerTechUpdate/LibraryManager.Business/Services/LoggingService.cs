﻿using System;
using System.IO;

namespace LibraryManager.Service.Services
{
    public class LoggingService
    {
        private readonly string _logFilePath;

        public LoggingService()
        {
            var appDataPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LibraryManager");
            Directory.CreateDirectory(appDataPath); 

            _logFilePath = Path.Combine(appDataPath, "log.txt");
        }

        public void LogEvent(string eventType, string bookTitle, string userName)
        {
            var logEntry = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {eventType} - Book: {bookTitle}, User: {userName}";
            File.AppendAllText(_logFilePath, logEntry + Environment.NewLine);
        }
    }
}
