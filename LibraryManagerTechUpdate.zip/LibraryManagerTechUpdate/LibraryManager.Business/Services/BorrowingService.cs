﻿using LibraryManager.Data.Models;
using LibraryManager.Data.Repositories;

namespace LibraryManager.Service.Services
{
    public class BorrowingService
    {
        private readonly BorrowedBookRepository _borrowedBookRepository;
        private readonly UserRepository _userRepository;
        private readonly BookRepository _bookRepository; // Add this
        private readonly LoggingService _loggingService;

        public BorrowingService(BorrowedBookRepository borrowedBookRepository, UserRepository userRepository, BookRepository bookRepository, LoggingService loggingService)
        {
            _borrowedBookRepository = borrowedBookRepository;
            _userRepository = userRepository;
            _bookRepository = bookRepository; // Initialize this
            _loggingService = loggingService;
        }

        public bool CanBorrow(int userId)
        {
            var borrowedBooksCount = _borrowedBookRepository.GetAll().Count(borrowedBook => borrowedBook.BorrowerId == userId);
            return borrowedBooksCount < BorrowingLimits.MaxBooksPerUser;
        }

        public void Borrow(int bookId, int userId, DateTime from, DateTime to)
        {
            if (!CanBorrow(userId))
            {
                throw new InvalidOperationException("User has reached the maximum number of borrowed books.");
            }

            var borrowedBook = new BorrowedBook
            {
                BookId = bookId,
                BorrowerId = userId,
                From = from,
                To = to
            };

            _borrowedBookRepository.Add(borrowedBook);

            // Fetch user and book details
            var user = _userRepository.GetById(userId);
            var book = _bookRepository.GetById(bookId); // Fetch book details

            _loggingService.LogEvent("Borrowed", book?.Title ?? "Unknown", user?.Name ?? "Unknown");
        }

        public void Return(int bookId)
        {
            var borrowedBook = _borrowedBookRepository.GetAll().FirstOrDefault(borrowed => borrowed.BookId == bookId);

            if (borrowedBook == null)
            {
                return;
            }

            _borrowedBookRepository.Remove(borrowedBook);

            // Fetch user and book details
            var user = _userRepository.GetById(borrowedBook.BorrowerId);
            var book = _bookRepository.GetById(bookId); // Fetch book details

            _loggingService.LogEvent("Returned", book?.Title ?? "Unknown", user?.Name ?? "Unknown");
        }

        public bool IsBorrowed(int bookId)
        {
            return _borrowedBookRepository.GetAll().Any(borrowedBook => borrowedBook.BookId == bookId);
        }
    }

    public static class BorrowingLimits
    {
        public const int MaxBooksPerUser = 10; // Adjust this value as needed
    }
}
