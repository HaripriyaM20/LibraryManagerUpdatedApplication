namespace LibraryManager.Tests.Data.Repositories;

public class UserRepositoryTest
{
    
}